#Required Software:

Python 2.7
Jupyter Notebook
SKLearn
numpy
panda
matplotlib


#The following files are required to run the code-

1. telenor_hackathon-prepost-Final.ipynb (Final Code)
2. hack_data_preprocess.ipynb (Data Preprocessor)
3. processed_hackathon_prepost.csv  (processed output of data preprocessor from Telenor provided data file)
4. url_category.csv (URL categorization)
5. visuals.py
6. visuals.pyc



#PPT Reports-
1. Machine Learning  Hackathon_MLD-MAL- 002 Report.pptx


#Execution Instruction-

1. To run the code- extract the zip file and select the Final code from Jupyter Notebook.
2.  processed_hackathon_prepost.csv is required to run the Final Code.
3. visuals.py and visuals.pyc are required in the same folder.


#Test with unknown data-
1. Run Data Preprocessor, load the unknown test data and export the file.
2. URL categorization file is required for Data Preprocessor.
3. Run the Final code, load the test data, run the code till the data preprocessing ends (till one hot encoding of categorical features).


